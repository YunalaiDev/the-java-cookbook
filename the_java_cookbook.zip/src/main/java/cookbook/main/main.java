package cookbook.main;

import cookbook.view.DisplayFrame;

import javax.swing.*;

public class main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new DisplayFrame();
        });
    }
}
